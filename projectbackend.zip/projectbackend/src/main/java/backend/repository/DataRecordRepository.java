package backend.repository;


import backend.model.DataRecord;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DataRecordRepository extends JpaRepository<DataRecord, Long> {
}